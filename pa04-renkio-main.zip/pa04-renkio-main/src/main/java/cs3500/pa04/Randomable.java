package cs3500.pa04;

/**
 * Random class
 */
public interface Randomable {
  public int nextInt();
  public int nextInt(int size);
}
