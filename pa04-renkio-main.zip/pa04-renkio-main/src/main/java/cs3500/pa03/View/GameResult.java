package cs3500.pa03.View;

public enum GameResult {
  WIN, LOSE, TIE
}
