package cs3500;

import cs3500.pa04.Randomable;

public class MockRandom implements Randomable {

  @Override
  public int nextInt() {
    return 0;
  }

  @Override
  public int nextInt(int size) {
    return 0;
  }
}
